const express = require('express');
const router = express.Router();
const authRoute = require('./authRoute');
const reviewRoute = require('./postRoute');
// Use auth routes
router.use('/auth', authRoute);
router.use( reviewRoute);

module.exports = router;
